/**
 * Make a container resizable
 * @class DDResize
 * @namespace WireIt.util
 * @extends YAHOO.util.DragDrop
 * @constructor
 * @param {WireIt.Container} container The container that is to be resizable
 * @param {Object} config Configuration object
 */
WireIt.util.DDResize = function(container, config) {

	/**
	 * Configuration object
	 * <ul>
	 *   <li>minWidth: minimum width (default 50)</li>
	 *   <li>minHeight: minimum height (default 50)</li>
	 * </ul>
	 * @property myConf
	 */
	// WARNING: the object config cannot be called "config" because YAHOO.util.DragDrop already has a "config" property
	this.myConf = config || {};
	this.myConf.container = container;
	this.myConf.minWidth = this.myConf.minWidth || 50;
	this.myConf.minHeight = this.myConf.minHeight || 50;

	// Call the superconstructor
	WireIt.util.DDResize.superclass.constructor.apply(this, [container.el, container.ddResizeHandle]);

	// Set the resize handle
	this.setHandleElId(container.ddResizeHandle);

	/**
	 * The event fired when the container is resized
	 * @event eventResize
	 */
	this.eventResize = new YAHOO.util.CustomEvent("eventResize");
};

YAHOO.extend(WireIt.util.DDResize, YAHOO.util.DragDrop, {

	/**
	 * @method onMouseDown
	 */
	onMouseDown: function(e) {
		var panel = this.getEl();
		this.startWidth = panel.offsetWidth;
		this.startHeight = panel.offsetHeight;

		this.startPos = [YAHOO.util.Event.getPageX(e), YAHOO.util.Event.getPageY(e)];
	},

	/**
	 * @method onDrag
	 */
	onDrag: function(e) {
		var newPos = [YAHOO.util.Event.getPageX(e),  YAHOO.util.Event.getPageY(e)];

		var offsetX = newPos[0] - this.startPos[0];
		var offsetY = newPos[1] - this.startPos[1];

		var newWidth = Math.max(this.startWidth + offsetX, this.myConf.minWidth);
		var newHeight = Math.max(this.startHeight + offsetY, this.myConf.minHeight);

		var panel = this.getEl();
		panel.style.width = newWidth + "px";
		panel.style.height = newHeight + "px";

		// Fire the resize event
		this.eventResize.fire([newWidth, newHeight]);
	}
});
