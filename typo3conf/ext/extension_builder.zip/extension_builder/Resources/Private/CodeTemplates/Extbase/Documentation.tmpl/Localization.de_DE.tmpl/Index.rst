﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt


.. _start:

=============================================================
###PROJECT_NAME### (Deutsch)
=============================================================

.. only:: html

	:Klassifikation:
		extension_key

	:Version:
		|release|

	:Sprache:
		de

	:Beschreibung:
		Geben Sie eine Beschreibung ein.

	:Schlüsselwörter:
		komma-getrennte,Liste,von,Schlüsselwörtern

	:Copyright:
		###YEAR###

	:Autor:
		###AUTHOR###

	:E-Mail:
		author@example.com

	:Lizenz:
		Dieses Dokument wird unter der Open Content License, siehe
		http://www.opencontent.org/opl.shtml veröffentlicht.

	:Gerendert:
		|today|

	Der Inhalt dieses Dokuments bezieht sich auf TYPO3,
	ein GNU/GPL CMS-Framework auf `www.typo3.org <http://www.typo3.org/>`_.


	**Inhaltsverzeichnis**

.. toctree::
	:maxdepth: 5
	:titlesonly:
	:glob:

..	Introduction/Index
..	UserManual/Index
..	AdministratorManual/Index
..	Configuration/Index
..	DeveloperCorner/Index
..	KnownProblems/Index
..	ToDoList/Index
..	ChangeLog/Index
