<?php
return array(
	'tx_srfreecap_pi2' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath('sr_freecap') . 'pi2/class.tx_srfreecap_pi2.php',
);      
?>