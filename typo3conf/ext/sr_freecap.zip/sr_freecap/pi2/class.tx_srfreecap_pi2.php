<?php
require_once \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath('sr_freecap') . 'Classes/PiBaseApi.php';
?>