<?php
$MLANG['default']['tabs_images']['tab'] = 'website.gif';
$MLANG['default']['ll_ref'] = 'LLL:EXT:lang/locallang_mod_web.xlf';
$MCONF['defaultMod'] = 'list';
$MCONF['navFrameScript'] = '../../alt_db_navframe.php';
$MCONF['name'] = 'web';
$MCONF['access'] = 'user,group';
