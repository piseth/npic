<?php
return array(
	'Tx_About_Controller_AboutController' => 'TYPO3\\CMS\\About\\Controller\\AboutController',
	'Tx_About_Domain_Model_Extension' => 'TYPO3\\CMS\\About\\Domain\\Model\\Extension',
	'Tx_About_Domain_Repository_ExtensionRepository' => 'TYPO3\\CMS\\About\\Domain\\Repository\\ExtensionRepository',
	'Tx_About_ViewHelpers_SkinImageViewHelper' => 'TYPO3\\CMS\\About\\ViewHelpers\\SkinImageViewHelper',
);
